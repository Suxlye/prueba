// Exporta la API de Electron para ser utilizada en los servicios
export const electronAPI = window.electronAPI;