import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';

const Oferta = sequelize.define('Oferta', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  codigo: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  productoId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'Productos', // Nombre de la tabla relacionada
      key: 'id'
    }
  },
  descuento: {
    type: DataTypes.DECIMAL(5, 2), // Ej: 25.50%
    allowNull: false,
    validate: {
      min: 0.01,
      max: 100.00
    }
  },
  fechaInicio: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      isDate: true
    }
  },
  fechaFin: {
    type: DataTypes.DATE,
    allowNull: false,
    validate: {
      isDate: true,
      esFechaPosterior(value) {
        if (new Date(value) <= new Date(this.fechaInicio)) {
          throw new Error('La fecha fin debe ser posterior a la fecha de inicio');
        }
      }
    }
  },
  estado: {
    type: DataTypes.ENUM('activa', 'inactiva', 'expirada'),
    defaultValue: 'activa'
  },
  condiciones: {
    type: DataTypes.TEXT,
    allowNull: true
  }
}, {
  timestamps: true,
  tableName: 'ofertas',
  indexes: [
    {
      unique: true,
      fields: ['codigo']
    },
    {
      fields: ['fechaFin']
    },
    {
      fields: ['estado']
    }
  ],
  hooks: {
    beforeSave: (oferta) => {
      // Actualizar estado si la fecha de fin ha pasado
      if (new Date(oferta.fechaFin) < new Date()) {
        oferta.estado = 'expirada';
      }
    }
  }
});

export default Oferta;