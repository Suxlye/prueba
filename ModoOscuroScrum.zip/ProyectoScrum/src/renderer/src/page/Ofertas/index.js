import OfertasDashboard from "./OfertasDashboard"

export default OfertasDashboard

